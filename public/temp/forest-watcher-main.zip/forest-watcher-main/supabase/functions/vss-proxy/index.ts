import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const VSS_API_BASE = 'https://vss-api-qgrhjnqzr.brevlab.com';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const action = url.searchParams.get('action');
    
    console.log(`VSS Proxy: action=${action}, method=${req.method}`);

    if (action === 'upload') {
      // Stream the upload directly to VSS API to avoid memory issues
      const contentType = req.headers.get('content-type');
      
      console.log('Streaming upload to VSS API...');
      
      const response = await fetch(`${VSS_API_BASE}/files`, {
        method: 'POST',
        headers: {
          'Content-Type': contentType || 'multipart/form-data',
        },
        body: req.body,
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('VSS upload error:', errorText);
        throw new Error(`Upload failed: ${errorText}`);
      }

      const result = await response.json();
      console.log('Upload successful:', result);
      
      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (action === 'captions') {
      // Generate VLM captions
      const body = await req.json();
      
      console.log('Generating captions for file:', body.file_id);
      
      const response = await fetch(`${VSS_API_BASE}/generate_vlm_captions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: body.file_id,
          prompt: body.prompt,
          model: 'cosmos-reason1',
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('VSS captions error:', errorText);
        throw new Error(`Caption generation failed: ${errorText}`);
      }

      const result = await response.json();
      console.log('Captions generated');
      
      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (action === 'summarize') {
      // Summarize video
      const body = await req.json();
      
      console.log('Summarizing video:', body.file_id);
      
      const response = await fetch(`${VSS_API_BASE}/summarize`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: body.file_id,
          prompt: body.prompt,
          model: 'cosmos-reason1',
          enable_chat: true,
          caption_summarization_prompt: body.prompt || 'Summarize the key events in this video segment.',
          summary_aggregation_prompt: body.aggregation_prompt || 'Aggregate the summaries into a coherent overview.',
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('VSS summarize error:', errorText);
        throw new Error(`Summarization failed: ${errorText}`);
      }

      const result = await response.json();
      console.log('Summarization complete');
      
      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (action === 'chat') {
      // Chat completion
      const body = await req.json();
      
      console.log('Chat completion for file:', body.file_id);
      
      const response = await fetch(`${VSS_API_BASE}/chat/completions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: body.model || 'cosmos-reason1',
          messages: body.messages,
          id: body.file_id,
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('VSS chat error:', errorText);
        throw new Error(`Chat completion failed: ${errorText}`);
      }

      const result = await response.json();
      console.log('Chat completion done');
      
      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (action === 'file-info') {
      // Get file info
      const fileId = url.searchParams.get('file_id');
      
      const response = await fetch(`${VSS_API_BASE}/files/${fileId}`);

      if (!response.ok) {
        throw new Error('Failed to get file info');
      }

      const result = await response.json();
      
      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    throw new Error(`Unknown action: ${action}`);

  } catch (error: unknown) {
    console.error('VSS Proxy error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
