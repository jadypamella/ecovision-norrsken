import React from 'react';
import { Header } from '@/components/Header';
import { VideoUploader } from '@/components/VideoUploader';
import { AnalysisProgress } from '@/components/AnalysisProgress';
import { AnalysisResults } from '@/components/AnalysisResults';
import { useVideoAnalysis } from '@/hooks/useVideoAnalysis';
import { Button } from '@/components/ui/button';
import { RefreshCcw, Shield, Zap, Eye } from 'lucide-react';

const Index = () => {
  const { analysis, isProcessing, analyzeVideo, resetAnalysis } = useVideoAnalysis();

  const handleTimeClick = (time: string) => {
    console.log('Navigate to time:', time);
    // Future: integrate with video player
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8 space-y-8">
        {/* Hero Section - Only show when no analysis */}
        {!analysis && (
          <section className="text-center space-y-6 py-12 animate-fade-in">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-forest/10 border border-forest/30 text-forest text-sm font-medium">
              <Zap className="w-4 h-4" />
              Powered by NVIDIA Visual Insights
            </div>
            
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
              <span className="text-gradient-forest">AI-Powered</span> Forest
              <br />
              Monitoring System
            </h1>
            
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Upload surveillance footage to automatically detect wildfires, poaching activity, 
              illegal logging, and wildlife movement with precise timestamps.
            </p>

            <div className="flex flex-wrap justify-center gap-4 pt-4">
              {[
                { icon: Shield, label: 'Wildfire Detection' },
                { icon: Eye, label: 'Wildlife Tracking' },
                { icon: Zap, label: 'Real-time Analysis' },
              ].map(({ icon: Icon, label }) => (
                <div 
                  key={label}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg bg-secondary text-secondary-foreground"
                >
                  <Icon className="w-4 h-4 text-forest" />
                  <span className="text-sm">{label}</span>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Upload Section */}
        <section className="max-w-2xl mx-auto space-y-6">
          {analysis && analysis.status !== 'completed' && (
            <AnalysisProgress analysis={analysis} />
          )}

          {(!analysis || analysis.status === 'error') && (
            <div className="space-y-4">
              <VideoUploader
                onUpload={analyzeVideo}
                isUploading={isProcessing}
                disabled={isProcessing}
              />
              
              {analysis?.status === 'error' && (
                <div className="text-center">
                  <Button 
                    onClick={resetAnalysis}
                    variant="outline"
                    className="gap-2"
                  >
                    <RefreshCcw className="w-4 h-4" />
                    Try Again
                  </Button>
                </div>
              )}
            </div>
          )}
        </section>

        {/* Results Section */}
        {analysis && analysis.status === 'completed' && (
          <section className="space-y-6 animate-fade-in">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold">Analysis Results</h2>
                <p className="text-muted-foreground">
                  {analysis.events.length} events detected in {analysis.fileName}
                </p>
              </div>
              <Button 
                onClick={resetAnalysis}
                variant="outline"
                className="gap-2"
              >
                <RefreshCcw className="w-4 h-4" />
                New Analysis
              </Button>
            </div>

            <AnalysisResults 
              analysis={analysis} 
              onTimeClick={handleTimeClick}
            />
          </section>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-border/50 py-6 mt-12">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>ForestWatch — AI-powered forest surveillance system</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
