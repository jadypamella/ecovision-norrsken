import React, { useState } from 'react';
import { Flame, Target, TreeDeciduous, Users, Squirrel, Clock, FileText, BarChart3 } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TimelineEvent } from './TimelineEvent';
import { cn } from '@/lib/utils';
import type { AnalysisResult, RiskCategory, TimelineEvent as TimelineEventType } from '@/types/analysis';

interface AnalysisResultsProps {
  analysis: AnalysisResult;
  onTimeClick?: (time: string) => void;
}

const CATEGORY_STATS: Record<RiskCategory, {
  icon: React.ElementType;
  color: string;
  bgColor: string;
  label: string;
}> = {
  wildfire: {
    icon: Flame,
    color: 'text-danger',
    bgColor: 'bg-danger/10',
    label: 'Wildfire',
  },
  poaching: {
    icon: Target,
    color: 'text-amber',
    bgColor: 'bg-amber/10',
    label: 'Poaching',
  },
  logging: {
    icon: TreeDeciduous,
    color: 'text-amber',
    bgColor: 'bg-amber/10',
    label: 'Logging',
  },
  safe_human: {
    icon: Users,
    color: 'text-forest',
    bgColor: 'bg-forest/10',
    label: 'Safe',
  },
  wildlife: {
    icon: Squirrel,
    color: 'text-sky',
    bgColor: 'bg-sky/10',
    label: 'Wildlife',
  },
};

export function AnalysisResults({ analysis, onTimeClick }: AnalysisResultsProps) {
  const [activeCategory, setActiveCategory] = useState<RiskCategory | 'all'>('all');

  const categoryCounts = analysis.events.reduce((acc, event) => {
    acc[event.category] = (acc[event.category] || 0) + 1;
    return acc;
  }, {} as Record<RiskCategory, number>);

  const highRiskCount = analysis.events.filter(e => e.riskLevel === 'high').length;

  const filteredEvents = activeCategory === 'all' 
    ? analysis.events 
    : analysis.events.filter(e => e.category === activeCategory);

  return (
    <div className="space-y-6">
      {/* Risk Summary */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {(Object.keys(CATEGORY_STATS) as RiskCategory[]).map((category) => {
          const config = CATEGORY_STATS[category];
          const Icon = config.icon;
          const count = categoryCounts[category] || 0;

          return (
            <button
              key={category}
              onClick={() => setActiveCategory(activeCategory === category ? 'all' : category)}
              className={cn(
                "p-4 rounded-xl border transition-all duration-300",
                "hover:scale-[1.02]",
                activeCategory === category 
                  ? cn(config.bgColor, "border-current", config.color)
                  : "glass-card border-border hover:border-border/80"
              )}
            >
              <div className="flex items-center gap-3">
                <div className={cn("p-2 rounded-lg", config.bgColor)}>
                  <Icon className={cn("w-4 h-4", config.color)} />
                </div>
                <div className="text-left">
                  <p className="text-2xl font-bold font-mono">{count}</p>
                  <p className="text-xs text-muted-foreground">{config.label}</p>
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Alert Banner for High Risk */}
      {highRiskCount > 0 && (
        <div className="p-4 rounded-xl bg-danger/10 border border-danger/30 flex items-center gap-3">
          <div className="p-2 rounded-lg bg-danger/20">
            <Flame className="w-5 h-5 text-danger animate-pulse" />
          </div>
          <div>
            <p className="font-medium text-danger">
              {highRiskCount} High Risk Event{highRiskCount > 1 ? 's' : ''} Detected
            </p>
            <p className="text-sm text-danger/80">
              Immediate attention may be required
            </p>
          </div>
        </div>
      )}

      {/* Tabs for different views */}
      <Tabs defaultValue="timeline" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-secondary">
          <TabsTrigger value="timeline" className="gap-2">
            <Clock className="w-4 h-4" />
            Timeline
          </TabsTrigger>
          <TabsTrigger value="summary" className="gap-2">
            <FileText className="w-4 h-4" />
            Summary
          </TabsTrigger>
          <TabsTrigger value="raw" className="gap-2">
            <BarChart3 className="w-4 h-4" />
            Raw Data
          </TabsTrigger>
        </TabsList>

        <TabsContent value="timeline" className="mt-4">
          <div className="space-y-3 max-h-[500px] overflow-y-auto scrollbar-thin pr-2">
            {filteredEvents.length > 0 ? (
              filteredEvents.map((event) => (
                <TimelineEvent
                  key={event.id}
                  event={event}
                  onClick={() => onTimeClick?.(event.startTime)}
                />
              ))
            ) : (
              <div className="text-center py-12 text-muted-foreground">
                No events found for this category
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="summary" className="mt-4">
          <div className="glass-card p-6 space-y-4">
            <h3 className="font-semibold flex items-center gap-2">
              <FileText className="w-5 h-5 text-forest" />
              Analysis Summary
            </h3>
            <p className="text-sm text-muted-foreground leading-relaxed whitespace-pre-wrap">
              {analysis.summary || 'No summary available'}
            </p>
          </div>
        </TabsContent>

        <TabsContent value="raw" className="mt-4">
          <div className="glass-card p-6 space-y-4">
            <h3 className="font-semibold flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-forest" />
              Raw Captions
            </h3>
            <pre className="text-xs text-muted-foreground font-mono whitespace-pre-wrap bg-background/50 p-4 rounded-lg overflow-auto max-h-[400px] scrollbar-thin">
              {analysis.rawCaptions || 'No raw data available'}
            </pre>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
