import React from 'react';
import { Loader2, CheckCircle2, AlertCircle, Film } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import type { AnalysisResult } from '@/types/analysis';

interface AnalysisProgressProps {
  analysis: AnalysisResult;
}

const STEPS = [
  { key: 'upload', label: 'Uploading Video', threshold: 20 },
  { key: 'caption', label: 'Generating Captions', threshold: 50 },
  { key: 'summarize', label: 'Summarizing Events', threshold: 75 },
  { key: 'aggregate', label: 'Categorizing Risks', threshold: 100 },
];

export function AnalysisProgress({ analysis }: AnalysisProgressProps) {
  const { status, progress, fileName } = analysis;

  const isCompleted = status === 'completed';
  const isError = status === 'error';

  return (
    <div className="glass-card p-6 space-y-6">
      <div className="flex items-center gap-4">
        <div className={cn(
          "p-3 rounded-xl transition-colors duration-300",
          isCompleted ? "bg-forest/20" : isError ? "bg-danger/20" : "bg-secondary"
        )}>
          {isCompleted ? (
            <CheckCircle2 className="w-6 h-6 text-forest" />
          ) : isError ? (
            <AlertCircle className="w-6 h-6 text-danger" />
          ) : (
            <Film className="w-6 h-6 text-forest animate-pulse" />
          )}
        </div>
        
        <div className="flex-1 min-w-0">
          <p className="font-medium truncate">{fileName}</p>
          <p className="text-sm text-muted-foreground">
            {isCompleted 
              ? 'Analysis Complete' 
              : isError 
                ? 'Analysis Failed' 
                : 'Processing...'}
          </p>
        </div>

        {!isCompleted && !isError && (
          <span className="text-2xl font-mono font-semibold text-forest">
            {progress}%
          </span>
        )}
      </div>

      {!isCompleted && !isError && (
        <>
          <Progress value={progress} className="h-2" />

          <div className="grid grid-cols-4 gap-2">
            {STEPS.map((step, index) => {
              const isActive = progress >= (STEPS[index - 1]?.threshold || 0) && progress < step.threshold;
              const isDone = progress >= step.threshold;

              return (
                <div
                  key={step.key}
                  className={cn(
                    "flex flex-col items-center gap-2 p-3 rounded-lg transition-all duration-300",
                    isDone 
                      ? "bg-forest/20" 
                      : isActive 
                        ? "bg-secondary" 
                        : "opacity-50"
                  )}
                >
                  <div className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-all duration-300",
                    isDone 
                      ? "bg-forest text-primary-foreground" 
                      : isActive 
                        ? "bg-forest/30 text-forest" 
                        : "bg-muted text-muted-foreground"
                  )}>
                    {isDone ? (
                      <CheckCircle2 className="w-4 h-4" />
                    ) : isActive ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      index + 1
                    )}
                  </div>
                  <span className={cn(
                    "text-xs text-center transition-colors duration-300",
                    isDone || isActive ? "text-foreground" : "text-muted-foreground"
                  )}>
                    {step.label}
                  </span>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}
