import React from 'react';
import { TreeDeciduous, Shield, Eye } from 'lucide-react';

export function Header() {
  return (
    <header className="border-b border-border/50 bg-card/50 backdrop-blur-xl sticky top-0 z-50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="p-2 rounded-xl bg-forest/20 glow-forest">
              <TreeDeciduous className="w-6 h-6 text-forest" />
            </div>
            <div className="absolute -bottom-1 -right-1 p-1 rounded-full bg-background border border-forest/50">
              <Eye className="w-3 h-3 text-forest" />
            </div>
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight">
              <span className="text-gradient-forest">Forest</span>
              <span className="text-foreground">Watch</span>
            </h1>
            <p className="text-xs text-muted-foreground">Wildlife & Wildfire Monitor</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-forest/10 border border-forest/30">
            <Shield className="w-4 h-4 text-forest" />
            <span className="text-xs font-medium text-forest">AI-Powered Analysis</span>
          </div>
        </div>
      </div>
    </header>
  );
}
