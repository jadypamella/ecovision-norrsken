import React, { useCallback, useState } from 'react';
import { Upload, Film, X, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface VideoUploaderProps {
  onUpload: (file: File) => void;
  isUploading: boolean;
  disabled?: boolean;
}

export function VideoUploader({ onUpload, isUploading, disabled }: VideoUploaderProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setIsDragging(true);
    } else if (e.type === 'dragleave') {
      setIsDragging(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const files = e.dataTransfer.files;
    if (files && files[0]) {
      const file = files[0];
      if (file.type.startsWith('video/')) {
        setSelectedFile(file);
      }
    }
  }, []);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files[0]) {
      setSelectedFile(files[0]);
    }
  }, []);

  const handleUpload = useCallback(() => {
    if (selectedFile) {
      onUpload(selectedFile);
    }
  }, [selectedFile, onUpload]);

  const clearSelection = useCallback(() => {
    setSelectedFile(null);
  }, []);

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024 * 1024) {
      return `${(bytes / 1024).toFixed(1)} KB`;
    }
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="w-full">
      {!selectedFile ? (
        <label
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
          className={cn(
            "relative flex flex-col items-center justify-center w-full h-64 border-2 border-dashed rounded-xl cursor-pointer transition-all duration-300",
            isDragging
              ? "border-forest bg-forest/10 scale-[1.02]"
              : "border-border hover:border-forest/50 hover:bg-secondary/50",
            disabled && "opacity-50 cursor-not-allowed"
          )}
        >
          <input
            type="file"
            accept="video/*"
            onChange={handleFileSelect}
            className="hidden"
            disabled={disabled}
          />
          
          <div className="flex flex-col items-center gap-4 p-6 text-center">
            <div className={cn(
              "p-4 rounded-2xl transition-all duration-300",
              isDragging ? "bg-forest/20" : "bg-secondary"
            )}>
              <Upload className={cn(
                "w-8 h-8 transition-colors duration-300",
                isDragging ? "text-forest" : "text-muted-foreground"
              )} />
            </div>
            
            <div className="space-y-2">
              <p className="text-lg font-medium">
                {isDragging ? "Drop your video here" : "Drag & drop video file"}
              </p>
              <p className="text-sm text-muted-foreground">
                or click to browse • MP4, MOV, AVI supported
              </p>
            </div>
          </div>

          {isDragging && (
            <div className="absolute inset-0 rounded-xl bg-forest/5 animate-pulse" />
          )}
        </label>
      ) : (
        <div className="glass-card p-6 space-y-4">
          <div className="flex items-center gap-4">
            <div className="p-3 rounded-xl bg-forest/20">
              <Film className="w-6 h-6 text-forest" />
            </div>
            
            <div className="flex-1 min-w-0">
              <p className="font-medium truncate">{selectedFile.name}</p>
              <p className="text-sm text-muted-foreground">
                {formatFileSize(selectedFile.size)}
              </p>
            </div>

            {!isUploading && (
              <Button
                variant="ghost"
                size="icon"
                onClick={clearSelection}
                className="shrink-0"
              >
                <X className="w-5 h-5" />
              </Button>
            )}
          </div>

          <Button
            onClick={handleUpload}
            disabled={isUploading || disabled}
            variant="forest"
            className="w-full"
            size="lg"
          >
            {isUploading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Uploading & Analyzing...
              </>
            ) : (
              <>
                <Upload className="w-5 h-5" />
                Start Analysis
              </>
            )}
          </Button>
        </div>
      )}
    </div>
  );
}
