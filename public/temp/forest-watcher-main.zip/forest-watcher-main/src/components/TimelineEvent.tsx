import React from 'react';
import { Clock, Flame, Target, TreeDeciduous, Users, Squirrel } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { TimelineEvent as TimelineEventType, RiskCategory } from '@/types/analysis';

interface TimelineEventProps {
  event: TimelineEventType;
  onClick?: () => void;
}

const CATEGORY_CONFIG: Record<RiskCategory, {
  icon: React.ElementType;
  color: string;
  bgColor: string;
  borderColor: string;
  label: string;
}> = {
  wildfire: {
    icon: Flame,
    color: 'text-danger',
    bgColor: 'bg-danger/10',
    borderColor: 'border-danger/30',
    label: 'Wildfire Risk',
  },
  poaching: {
    icon: Target,
    color: 'text-amber',
    bgColor: 'bg-amber/10',
    borderColor: 'border-amber/30',
    label: 'Poaching Activity',
  },
  logging: {
    icon: TreeDeciduous,
    color: 'text-amber',
    bgColor: 'bg-amber/10',
    borderColor: 'border-amber/30',
    label: 'Illegal Logging',
  },
  safe_human: {
    icon: Users,
    color: 'text-forest',
    bgColor: 'bg-forest/10',
    borderColor: 'border-forest/30',
    label: 'Safe Activity',
  },
  wildlife: {
    icon: Squirrel,
    color: 'text-sky',
    bgColor: 'bg-sky/10',
    borderColor: 'border-sky/30',
    label: 'Wildlife',
  },
};

export function TimelineEvent({ event, onClick }: TimelineEventProps) {
  const config = CATEGORY_CONFIG[event.category];
  const Icon = config.icon;

  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full text-left p-4 rounded-xl border transition-all duration-300",
        "hover:scale-[1.02] hover:shadow-lg",
        config.bgColor,
        config.borderColor
      )}
    >
      <div className="flex items-start gap-3">
        <div className={cn(
          "p-2 rounded-lg shrink-0",
          config.bgColor
        )}>
          <Icon className={cn("w-5 h-5", config.color)} />
        </div>

        <div className="flex-1 min-w-0 space-y-2">
          <div className="flex items-center justify-between gap-2">
            <span className={cn("text-sm font-medium", config.color)}>
              {config.label}
            </span>
            <span className={cn(
              "text-xs px-2 py-0.5 rounded-full font-medium",
              event.riskLevel === 'high' 
                ? "bg-danger/20 text-danger" 
                : event.riskLevel === 'medium'
                  ? "bg-amber/20 text-amber"
                  : "bg-forest/20 text-forest"
            )}>
              {event.riskLevel.toUpperCase()}
            </span>
          </div>

          <p className="text-sm text-foreground/90 leading-relaxed">
            {event.description}
          </p>

          <div className="flex items-center gap-2 text-xs text-muted-foreground font-mono">
            <Clock className="w-3 h-3" />
            <span>{event.startTime}</span>
            <span>→</span>
            <span>{event.endTime}</span>
          </div>
        </div>
      </div>
    </button>
  );
}
